import axios from "axios";
import React, {useState} from "react";
import { Container, Button, Row, Col, Card, Form, Image } from "react-bootstrap";

function App() {

  const url = "http://localhost:5000/"

  const [fileToUpload, setFileToUpload] = useState();
  const [lastUploadedFile, setLastUploadedFile] = useState('');

  const uploadFileToServer = async ()=>{
    try {
      const formData = new FormData();
      formData.append("file",fileToUpload); 

      const res = await axios.post(`${url}file`, formData);
      console.log('file uploaded',res);
      setLastUploadedFile(res.data.path)
    } catch (error) {
      console.log('Failed to upload file', error);
    }
  }

  return (
    <div>
      <Container className="pt-2">
        <Card>
          <Card.Body>
            <Form>
              <Row className="align-items-center">
                <Col sm={6} className="my-1">
                  <Form.Label htmlFor="inlineFormInputName" visuallyHidden>
                    File
                  </Form.Label>
                  <Form.Control
                  type="file"
                  onChange={(e)=> setFileToUpload(e.target.files[0])}
                    id="inlineFormInputName"
                    placeholder="Click to upload file"
                  />
                </Col>
               
               
                <Col xs="auto" className="my-1">
                  <Button onClick={uploadFileToServer}>Upload</Button>
                </Col>
              </Row>
            </Form>

            <Container>
              {lastUploadedFile && (<Image width={'150px'} src={lastUploadedFile} />)}
            </Container>
          </Card.Body>
        </Card>
      </Container>
    </div>
  );
}

export default App;
